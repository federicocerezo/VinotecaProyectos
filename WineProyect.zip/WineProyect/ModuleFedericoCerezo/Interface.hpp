/*
 * @author Federico Cerezo Liebing
 */
 
#ifndef Interface_hpp
#define Interface_hpp


#include <iostream>

using namespace std;

#include "Program.hpp"


void interface();

#endif 