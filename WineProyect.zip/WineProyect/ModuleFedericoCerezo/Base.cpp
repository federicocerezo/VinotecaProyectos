/*
 * @author Federico Cerezo Liebing
 */
#include "Base.hpp"

int Base::getId() const { 
    return id;
}

string Base::getName() const { 
    return name;
}

