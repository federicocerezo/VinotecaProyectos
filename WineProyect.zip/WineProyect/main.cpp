
#include <iostream>

#include "ModuleFedericoCerezo/Interface.hpp"

using namespace std;

int main(){
    interface();
    return 0;
}